#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <cuda_runtime.h>

typedef struct Sparse_CSR {
    int n_row;
    int n_cols;
    int n_nz;
    int* row_ptrs;
    int* col_indices;
    double* values;
} Sparse_CSR;

void read_mtx_file(const char *filename, Sparse_CSR *csr_matrix){
	
	//open file
	FILE *file = fopen(filename, "r");
	if(!file) {
		perror("Unable to open file!");
		exit(EXIT_FAILURE);
	}
	
	//skip comments
	char line[256];
	while (fgets(line, sizeof(line), file)) {
            if (line[0] != '%') break;
    	}
	
	//initialize variable to store coo matrix from file
	int coo_rown, coo_coln, coo_nnz;
	
	//input no of rows, columns and non-zeros
	sscanf(line, "%d %d %d", &coo_rown, &coo_coln, &coo_nnz);
	printf("row = %d , col = %d , nz = %d\n", coo_rown, coo_coln, coo_nnz);
	
	//allocate memory to store the coo values
	int* coo_rows  = (int *)malloc(coo_nnz * sizeof(int));
	int* coo_cols = (int *)malloc(coo_nnz * sizeof(int));
	double* coo_val = (double *)malloc(coo_nnz * sizeof(double));
	
	if (!coo_rows || !coo_cols || !coo_val){
		perror("Memory Allocation failed!");
		fclose(file);
		exit(EXIT_FAILURE);
	}
	
	for(int i = 0; i < coo_nnz ; i++){
		fscanf(file, "%d %d %lf" , &coo_rows[i], &coo_cols[i], &coo_val[i]);
	}
	
	//variable assignment
	csr_matrix->n_row = coo_rown;
	csr_matrix->n_cols = coo_coln;
	csr_matrix->n_nz = coo_nnz;


	// Allocate CSR format arrays
	csr_matrix->row_ptrs = (int *)malloc((coo_rown + 1) * sizeof(int));
	memset(csr_matrix->row_ptrs, 0, (coo_rown + 1) * sizeof(int)); // Initialize to 0

	csr_matrix->col_indices = (int *)malloc(coo_nnz * sizeof(int));
	csr_matrix->values = (double *)malloc(coo_nnz * sizeof(double));

	// Step 1: Count non-zero elements per row
	for (int i = 0; i < coo_nnz; i++) {
		csr_matrix->row_ptrs[coo_rows[i]]++;
	}

	// Convert counts to starting indices
    	int sum = 0;
    	for (int i = 0; i <= coo_rown; i++) {
        	int temp = csr_matrix->row_ptrs[i];
        	csr_matrix->row_ptrs[i] = sum;
        	sum += temp;
	}

	// Step 3: Fill CSR format data
	for (int i = 0; i < coo_nnz; i++) {
	        int row = coo_rows[i];
	        int dest = csr_matrix->row_ptrs[row];

	        csr_matrix->col_indices[dest] = coo_cols[i]-1;
	        csr_matrix->values[dest] = coo_val[i];

	        csr_matrix->row_ptrs[row]++;
	}
	

	//free temporary allocations
	free(coo_rows);
	free(coo_cols);
	free(coo_val);
	
}

int print_sparse_csr(const Sparse_CSR* csr_matrix) {
    printf("nz_id\trow\tcol\tmat_val\n");
    printf("----\n");
    
        for (size_t i=0; i<csr_matrix->n_row; ++i) {
            size_t nz_start = csr_matrix->row_ptrs[i];
            size_t nz_end = csr_matrix->row_ptrs[i+1];
            for (size_t nz_id=nz_start; nz_id<nz_end; ++nz_id) {
                size_t j = csr_matrix->col_indices[nz_id];
                double val = csr_matrix->values[nz_id];
                printf("%d\t%d\t%d\t%lf\n",nz_id, i, j, val);
            }
        }
    
    return EXIT_SUCCESS;
}

int free_sparse_csr(Sparse_CSR* csr_matrix) {
    free(csr_matrix->row_ptrs);
    free(csr_matrix->col_indices);
    free(csr_matrix->values);

    return EXIT_SUCCESS;
}

int* vec_gen(int vec_row, int vec_col, unsigned int seed){
	srand(seed);
	
	int* vector = (int*)malloc(vec_row * vec_col * sizeof(int));
	
	if(vector == NULL){ 
		return NULL;
	}
	
	for (int i = 0; i < vec_row; i++){
		for (int j = 0; j < vec_col; j++){
			vector[i * vec_col + j] = rand()%10;
		}
	}	
	
	return vector;
}

double* multiplication_cuda(const Sparse_CSR* csr_matrix, const int* vector, int vec_col);

__global__ void matrix_vector_multiplication(const int num_rows, const int vec_col, const int *row_ptrs, const int *col_indices, const double *mat_val,	const int *vec_val, double* res);


int main(int argc, char** argv) {
	Sparse_CSR csr_matrix;
	unsigned int seed = 1;
	
	read_mtx_file( "mhd4800a.mtx" , &csr_matrix);

	//printf("Printing CSR Matrix after storing it");
	//print_sparse_csr(&csr_matrix);
	
	int* vec_k1 = vec_gen(csr_matrix.n_cols, 1, seed);
	int* vec_k2 = vec_gen(csr_matrix.n_cols, 2, seed);
	int* vec_k3 = vec_gen(csr_matrix.n_cols, 3, seed);
	int* vec_k6 = vec_gen(csr_matrix.n_cols, 6, seed);
	
	double* result_k1 = multiplication_cuda(&csr_matrix, vec_k1, 1);
	double* result_k2 = multiplication_cuda(&csr_matrix, vec_k2, 2);
	double* result_k3 = multiplication_cuda(&csr_matrix, vec_k3, 3);
	double* result_k6 = multiplication_cuda(&csr_matrix, vec_k6, 6);


	free_sparse_csr(&csr_matrix);
	free(vec_k1);
	free(vec_k2);
	free(vec_k3);
	free(vec_k6);
	free(result_k1);
	free(result_k2);
	free(result_k3);
	free(result_k6);
	
	return EXIT_SUCCESS;
}

double* multiplication_cuda(const Sparse_CSR* csr_matrix, const int* vector, int vec_col){
	double* result = (double*)calloc(csr_matrix->n_row * vec_col , sizeof(double));

	if (result == NULL) {
	        fprintf(stderr, "Failed to allocate memory for result\n");
	        exit(EXIT_FAILURE);
	}
	
	//variable intialization
	int *d_row_ptr, *d_col_ind, *d_vec;
	double *d_values, *d_result;

// Allocating kernel memory and checking for errors
	cudaError_t err;
	
	//allocating kernal memory
	cudaMalloc(&d_row_ptr, (csr_matrix->n_row+1) * sizeof(int));
	cudaMalloc(&d_col_ind, csr_matrix->n_nz * sizeof(int));
	cudaMalloc(&d_values, csr_matrix->n_nz * sizeof(double));
	cudaMalloc(&d_vec, (csr_matrix->n_cols*vec_col) * sizeof(int));
	cudaMalloc(&d_result, (csr_matrix->n_row*vec_col) * sizeof(double));
	
	//moving data from CPU to GPU
	cudaMemcpy(d_row_ptr, csr_matrix->row_ptrs, (csr_matrix->n_row+1)*sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(d_col_ind, csr_matrix->col_indices, csr_matrix->n_nz*sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(d_values, csr_matrix->values, csr_matrix->n_nz*sizeof(double), cudaMemcpyHostToDevice);
	cudaMemcpy(d_vec, vector, (csr_matrix->n_cols*vec_col)*sizeof(int), cudaMemcpyHostToDevice);
	cudaMemcpy(d_result, result, (csr_matrix->n_row*vec_col)*sizeof(double), cudaMemcpyHostToDevice);
	
	//cuda event intialization
	cudaEvent_t start,stop;
	cudaEventCreate(&start);
	cudaEventCreate(&stop);	
	
	cudaEventRecord(start);
	//initializing kernel variables
	int threadsperblock  = 1024;
	int numblock = ceil(csr_matrix->n_row/threadsperblock);

	if( ceil(csr_matrix->n_row/threadsperblock) == 0) {
		numblock = 1;
	} else {
		numblock = ceil(csr_matrix->n_row/threadsperblock);
	}


	//printf("threadsperblock = %d, numblock = %d", threadsperblock, numblock);
	
	//launching kernels
	
	matrix_vector_multiplication<<< numblock , threadsperblock >>>(csr_matrix->n_row, vec_col, d_row_ptr, d_col_ind, d_values, d_vec, d_result);
	// Check for kernel launch errors
	err = cudaGetLastError();
	if (err != cudaSuccess) {
	        fprintf(stderr, "Failed to launch matrix_vector_multiplication kernel: %s\n", cudaGetErrorString(err));
		exit(EXIT_FAILURE);
	}
	
	cudaMemcpy(result, d_result, (csr_matrix->n_row*vec_col)*sizeof(double), cudaMemcpyDeviceToHost);

	cudaEventRecord(stop);
	cudaEventSynchronize(stop);

	float time_elapsed;
	cudaEventElapsedTime(&time_elapsed, start, stop);
	printf("Time elapsed for executing with vector columns %d = %lf\n", vec_col, time_elapsed); 
	
	cudaFree(d_row_ptr);
	cudaFree(d_col_ind);
	cudaFree(d_values);
	cudaFree(d_vec);
	cudaFree(d_result);
	
	return result;
}


__global__ void matrix_vector_multiplication(const int num_rows, const int vec_col, const int *row_ptrs, const int *col_indices, const double *mat_val,	const int *vec_val, double* res){
	int row = blockIdx.x * blockDim.x + threadIdx.x;

	//printf("row = %d , col = %d, num_rows = %d", row, col, num_rows);
	
	int i, row_start, row_end;
	double dot;
	
	if (row < num_rows){
		for(int k = 0; k<vec_col; k++){
			dot = 0.0;
			row_start = row_ptrs[row];
			row_end = row_ptrs[row+1];
			for(i = row_start; i<row_end ; i++){
				dot += mat_val[i] * vec_val[(col_indices[i])*vec_col+k];
			}
			res[row*vec_col+k] = dot;
		}
	}
}