#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <omp.h>

typedef struct Sparse_CSR {
    int n_row;
    int n_cols;
    int n_nz;
    int* row_ptrs;
    int* col_indices;
    double* values;
} Sparse_CSR;

void read_mtx_file(const char *filename, Sparse_CSR *csr_matrix){
	
	//open file
	FILE *file = fopen(filename, "r");
	if(!file) {
		perror("Unable to open file!");
		exit(EXIT_FAILURE);
	}
	
	//skip comments
	char line[256];
	while (fgets(line, sizeof(line), file)) {
            if (line[0] != '%') break;
    	}
	
	//initialize variable to store coo matrix from file
	int coo_rown, coo_coln, coo_nnz;
	
	//input no of rows, columns and non-zeros
	sscanf(line, "%d %d %d", &coo_rown, &coo_coln, &coo_nnz);
	printf("row = %d , col = %d , nz = %d\n", coo_rown, coo_coln, coo_nnz);
	
	//allocate memory to store the coo values
	int* coo_rows  = (int *)malloc(coo_nnz * sizeof(int));
	int* coo_cols = (int *)malloc(coo_nnz * sizeof(int));
	double* coo_val = (double *)malloc(coo_nnz * sizeof(double));
	
	if (!coo_rows || !coo_cols || !coo_nnz){
		perror("Memory Allocation failed!");
		fclose(file);
		exit(EXIT_FAILURE);
	}
	
	for(int i = 0; i < coo_nnz ; i++){
		fscanf(file, "%d %d %lf" , &coo_rows[i], &coo_cols[i], &coo_val[i]);
	}
	
	//variable assignment
	csr_matrix->n_row = coo_rown;
	csr_matrix->n_cols = coo_coln;
	csr_matrix->n_nz = coo_nnz;


	// Allocate CSR format arrays
	csr_matrix->row_ptrs = (int *)malloc((coo_rown + 1) * sizeof(int));
	memset(csr_matrix->row_ptrs, 0, (coo_rown + 1) * sizeof(int)); // Initialize to 0

	csr_matrix->col_indices = (int *)malloc(coo_nnz * sizeof(int));
	csr_matrix->values = (double *)malloc(coo_nnz * sizeof(double));

	// Step 1: Count non-zero elements per row
	for (int i = 0; i < coo_nnz; i++) {
		csr_matrix->row_ptrs[coo_rows[i]]++;
	}

	// Convert counts to starting indices
    	int sum = 0;
    	for (int i = 0; i <= coo_rown; i++) {
        	int temp = csr_matrix->row_ptrs[i];
        	csr_matrix->row_ptrs[i] = sum;
        	sum += temp;
	}

	// Step 3: Fill CSR format data
	for (int i = 0; i < coo_nnz; i++) {
	        int row = coo_rows[i];
	        int dest = csr_matrix->row_ptrs[row];

	        csr_matrix->col_indices[dest] = coo_cols[i]-1;
	        csr_matrix->values[dest] = coo_val[i];

	        csr_matrix->row_ptrs[row]++;
	}
	

	//free temporary allocations
	free(coo_rows);
	free(coo_cols);
	free(coo_val);
	
}

int print_sparse_csr(const Sparse_CSR* csr_matrix) {
    printf("nz_id\trow\tcol\tmat_val\n");
    printf("----\n");
    
        for (size_t i=0; i<csr_matrix->n_row; ++i) {
            size_t nz_start = csr_matrix->row_ptrs[i];
            size_t nz_end = csr_matrix->row_ptrs[i+1];
            for (size_t nz_id=nz_start; nz_id<nz_end; ++nz_id) {
                size_t j = csr_matrix->col_indices[nz_id];
                double val = csr_matrix->values[nz_id];
                printf("%d\t%d\t%d\t%lf\n",nz_id, i, j, val);
            }
        }
    
    return EXIT_SUCCESS;
}

int free_sparse_csr(Sparse_CSR* csr_matrix) {
    free(csr_matrix->row_ptrs);
    free(csr_matrix->col_indices);
    free(csr_matrix->values);

    return EXIT_SUCCESS;
}

int* vec_gen(int vec_row, int vec_col, unsigned int seed){
	srand(seed);
	
	int* vector = (int*)malloc(vec_row * vec_col * sizeof(int));
	
	if(vector == NULL){ 
		return NULL;
	}
	
	for (int i = 0; i < vec_row; i++){
		for (int j = 0; j < vec_col; j++){
			vector[i * vec_col + j] = rand()%10;
		}
	}	
	
	return vector;
}

double* multiplication_openmp(const Sparse_CSR* csr_matrix, const int* vector, int vec_col);

int main(int argc, char** argv) {
	Sparse_CSR csr_matrix;
	unsigned int seed = 1;
	
	read_mtx_file("mhd4800a.mtx" , &csr_matrix);

	//printf("Printing CSR Matrix after storing it");
	//print_sparse_csr(&csr_matrix);
	//printf("-------------------------------------------------");
	
	int* vec_k1 = vec_gen(csr_matrix.n_cols, 1, seed);
	int* vec_k2 = vec_gen(csr_matrix.n_cols, 2, seed);
	int* vec_k3 = vec_gen(csr_matrix.n_cols, 3, seed);
	int* vec_k6 = vec_gen(csr_matrix.n_cols, 6, seed);
	
	double* result_k1 = multiplication_openmp(&csr_matrix, vec_k1, 1);
	double* result_k2 = multiplication_openmp(&csr_matrix, vec_k2, 2);
	double* result_k3 = multiplication_openmp(&csr_matrix, vec_k3, 3);
	double* result_k6 = multiplication_openmp(&csr_matrix, vec_k6, 6);
	
	free_sparse_csr(&csr_matrix);
	free(vec_k1);
	free(vec_k2);
	free(vec_k3);
	free(vec_k6);
	free(result_k1);
	free(result_k2);
	free(result_k3);
	free(result_k6);
	
	return EXIT_SUCCESS;
}

double* multiplication_openmp(const Sparse_CSR* csr_matrix, const int* vector, int vec_col){
	double* result = (double *)malloc(csr_matrix->n_row * vec_col * sizeof(double));
	
	if(result == NULL){
		perror("Failed to allocate memory for result");
		exit(EXIT_FAILURE);
	}
	
	int i, j, k, nz_start, nz_end, nz_id, vec_val;
	double mat_val, temp;

	char* ompThreads = getenv("OMP_NUM_THREADS");
	int numThreads = atoi(ompThreads);
	double start, end, execution_time;
	start = omp_get_wtime();
	
	#pragma omp parallel for private (i, j, k, nz_start, nz_end, nz_id, mat_val, vec_val, temp)
	for(k = 0; k<vec_col; k++){
		for(i=0 ; i < csr_matrix->n_row; i++){
			temp = 0.0;
			nz_start = csr_matrix->row_ptrs[i];
			nz_end = csr_matrix->row_ptrs[i+1];
			for(nz_id = nz_start ; nz_id < nz_end ; nz_id++){
				j = csr_matrix->col_indices[nz_id];
				mat_val = csr_matrix->values[nz_id];
				vec_val = vector[(j)*vec_col + k];
				temp += (mat_val*vec_val);
			}
			result[i*vec_col+k] = temp;
		}
	}
	#pragma omp barrier
	end = omp_get_wtime();
	execution_time = end - start;
	printf("Execution time for %d threads and %d columns = %lf seconds.\n", numThreads, vec_col, execution_time);
		
	return result;
}
